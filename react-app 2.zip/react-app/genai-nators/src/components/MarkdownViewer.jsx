import React from 'react';
import ReactMarkdown from 'react-markdown';
import remarkGfm from 'remark-gfm';
import { Link, Element } from 'react-scroll';  // Add Element import

const MarkdownViewer = ({ content }) => {
  const headers = content
    .split('\n')
    .filter(line => line.startsWith('#'))
    .map(header => ({
      level: header.match(/^#+/)[0].length,
      text: header.replace(/^#+\s/, ''),
      id: header.replace(/^#+\s/, '').toLowerCase().replace(/\s/g, '-')
    }));

  return (
    <div className="grid grid-cols-4 gap-8 p-6 rounded-xl bg-gradient-to-r from-blue-50 to-cyan-50">
      {/* Table of Contents */}
      <div className="col-span-1 bg-white p-6 rounded-lg shadow-lg sticky top-4 h-fit max-h-[calc(100vh-2rem)] overflow-y-auto border border-gray-100">
        <h3 className="text-xl font-bold mb-6 text-gray-800">Table of Contents</h3>
        <nav className="space-y-2">
          {headers.map((header, index) => (
            <Link
              key={index}
              to={header.id}
              spy={true}
              smooth={true}
              duration={500}
              offset={-20}
              activeClass="text-blue-600 font-medium"
              className={`
                block cursor-pointer text-gray-600 hover:text-blue-600 transition-colors
                ${header.level === 1 ? 'font-semibold' : ''}
                ${header.level === 2 ? 'ml-2' : ''}
                ${header.level === 3 ? 'ml-4 text-sm' : ''}
              `}
            >
              {header.text}
            </Link>
          ))}
        </nav>
      </div>

      {/* Markdown Content */}
      <div className="col-span-3 prose prose-slate max-w-none bg-white p-8 rounded-lg shadow-lg">
        <ReactMarkdown 
          remarkPlugins={[remarkGfm]}
          components={{
            h1: ({node, children, ...props}) => (
              <Element name={children[0].toLowerCase().replace(/\s/g, '-')} className="scroll-mt-6">
                <h1 
                  className="text-3xl font-bold mb-6 pb-2 border-b border-gray-200"
                  {...props}
                >
                  {children}
                </h1>
              </Element>
            ),
            h2: ({node, children, ...props}) => (
              <Element name={children[0].toLowerCase().replace(/\s/g, '-')} className="scroll-mt-6">
                <h2 
                  className="text-2xl font-semibold mt-8 mb-4"
                  {...props}
                >
                  {children}
                </h2>
              </Element>
            ),
            h3: ({node, children, ...props}) => (
              <Element name={children[0].toLowerCase().replace(/\s/g, '-')} className="scroll-mt-6">
                <h3 
                  className="text-xl font-medium mt-6 mb-3"
                  {...props}
                >
                  {children}
                </h3>
              </Element>
            ),
            table: ({node, ...props}) => (
              <div className="overflow-x-auto my-6">
                <table className="min-w-full divide-y divide-gray-300" {...props} />
              </div>
            ),
            thead: ({node, ...props}) => (
              <thead className="bg-gray-50" {...props} />
            ),
            th: ({node, ...props}) => (
              <th 
                className="px-6 py-3 text-left text-sm font-semibold text-gray-900"
                {...props} 
              />
            ),
            td: ({node, ...props}) => (
              <td 
                className="px-6 py-4 whitespace-nowrap text-sm text-gray-500"
                {...props} 
              />
            ),
            tr: ({node, ...props}) => (
              <tr 
                className="even:bg-gray-50"
                {...props} 
              />
            ),
            p: ({node, ...props}) => (
              <p className="my-4 text-gray-600 leading-relaxed" {...props} />
            ),
            strong: ({node, ...props}) => (
              <strong className="font-semibold text-gray-900" {...props} />
            ),
            ul: ({node, ...props}) => (
              <ul className="list-disc pl-6 my-4 space-y-2" {...props} />
            ),
            li: ({node, ...props}) => (
              <li className="text-gray-600" {...props} />
            )
         }}
        >
          {content}
        </ReactMarkdown>
      </div>
    </div>
  );
};

export default MarkdownViewer;