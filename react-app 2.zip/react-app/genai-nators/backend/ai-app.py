from flask import Flask, request, jsonify
from flask_cors import CORS
import os
import shutil
import git
from pathlib import Path
import vertexai
from magika import Magika
from vertexai.preview import caching
from vertexai.generative_models import (
    FunctionDeclaration,
    GenerationConfig,
    GenerativeModel,
    Tool,
)
import re
import datetime

app = Flask(__name__)
CORS(app)

def clone_repo(repo_url, repo_dir):
    """Clone a GitHub repository."""
    if os.path.exists(repo_dir):
        shutil.rmtree(repo_dir)
    os.makedirs(repo_dir)
    git.Repo.clone_from(repo_url, repo_dir)

def extract_code(repo_dir, m):
    """Create an index and extract content of specific code/text files."""
    allowed_extensions = ['bwccp']
    code_index = []
    code_files = {}

    for root, _, files in os.walk(repo_dir):
        for file in files:
            file_extension = os.path.splitext(file)[1][1:]
            if file_extension not in allowed_extensions:
                file_path = os.path.join(root, file)
                relative_path = os.path.relpath(file_path, repo_dir)
                code_index.append(relative_path)

                file_type = m.identify_path(Path(file_path))
                if file_type.output.group in ("text", "code"):
                    try:
                        with open(file_path) as f:
                            code_files[relative_path] = f.read()
                    except Exception:
                        pass

    return code_index, code_files

def get_code_prompt(question, code_index, code_files, basis):
    """Generates a prompt to a code-related question, passing files separately."""
    file_details = ""
    for file_name, file_content in code_files.items():
        file_details += f"----- File: {file_name} -----\n"
        file_details += file_content
        file_details += "\n-------------------------\n"

    prompt = f"""
    Questions: {question}
    - Here is an index of all of the files in the codebase:
      \n\n{code_index}\n\n.
    - Here are the contents of the files separately:
      \n\n{file_details}\n\n.
    - The basis and best practices for migrating from {basis} to MuleSoft is below:
      \n\n{basis}\n\n
    """
    return prompt

@app.route('/migrate', methods=['POST'])
def migrate():
    data = request.json
    main_api_key = '4HhQfVUp3tZXNwPSnXpW'
    repo_url = data.get('repo_url')
    MODEL_ID = data.get('model_id', 'gemini-1.5-flash-001')
    question = data.get('question')
    system_information = data.get('system_information')
    basis = data.get('basis', "")  # You might want to provide a default basis if not given
    api_key = data.get('api_key')
    # Set project and cloud settings
    PROJECT_ID = "ehc-ctoner-1d0e2f"
    LOCATION = "us-central1"

    SERVICE_ACCOUNT_KEY_FILE = '/Users/patryk.sobczak/Documents/Social Events/Hackathon/caitlin-key.json'
    os.environ["GOOGLE_APPLICATION_CREDENTIALS"] = SERVICE_ACCOUNT_KEY_FILE

    vertexai.init(project=PROJECT_ID, location=LOCATION)
    m = Magika()

    if api_key != main_api_key:
        return 'API Key not matching'

    if not all([repo_url, MODEL_ID, question, system_information]):
        return jsonify({"error": "Missing required parameters"}), 400

    repo_dir = "./repo"

    try:
        clone_repo(repo_url, repo_dir)
        code_index, code_files = extract_code(repo_dir, m)
        prompt = get_code_prompt(question, code_index, code_files, basis)

        model = GenerativeModel(
            MODEL_ID,
            system_instruction=system_information,
        )

        response = model.generate_content([prompt])

        return jsonify({"response": response.text})
    except Exception as e:
        return jsonify({"error": str(e)}), 500
    finally:
        if os.path.exists(repo_dir):
            shutil.rmtree(repo_dir)

if __name__ == '__main__':
    app.run(port=5001, debug=True)