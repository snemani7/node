import React, { useState, useEffect } from 'react';
import InputForm from './components/InputForm';
import MarkdownViewer from './components/MarkdownViewer';
import Title from './components/Title';
import VideoSection from './components/VideoSection';
import { systemInstructions, question, platformBasis } from './config/prompts';

function App() {
  const [markdownContent, setMarkdownContent] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState(null);
  const [loadingDots, setLoadingDots] = useState('...');

  useEffect(() => {
    let interval;
    if (isLoading) {
      interval = setInterval(() => {
        setLoadingDots(dots => dots === '...' ? '.' : dots + '.');
      }, 500);
    }
    return () => clearInterval(interval);
  }, [isLoading]);

  const handleSubmit = async (formData) => {
    setIsLoading(true);
    setError(null);

    console.log('Form Data in App.jsx:', formData);

    const apiPayload = {
      api_key: "4HhQfVUp3tZXNwPSnXpW",
      repo_url: formData.repoLink,
      model_name: "gemini-1.5-flash-001",
      question: question,
      system_information: systemInstructions,
      basis: platformBasis[formData.platform.toLowerCase()]
    };

    console.log('API Payload full:', apiPayload);

    try {
      const response = await fetch('http://127.0.0.1:5001/migrate', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(apiPayload)
      });

      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }

      const data = await response.json();
      console.log('Markdown API response:', data.response);
      setMarkdownContent(data.response);
    } catch (error) {
      console.error('Error:', error);
      setError('Failed to process request. Please try again.');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="flex flex-col">
      {/* <VideoSection /> */}
      <div id="main-content" className="min-h-screen flex flex-col">
        <header className="py-6 px-4">
          <Title />
        </header>
        <main className="container mx-auto px-4 flex-grow">
          <div className="grid grid-cols-1 gap-8">
            <InputForm onSubmit={handleSubmit} />
            {isLoading && (
              <div className="text-center">
                <span>Processing</span>
                <span className="inline-block w-[3ch]">{loadingDots}</span>
              </div>
            )}
            {error && <div className="text-red-500 text-center">{error}</div>}
            {markdownContent && <MarkdownViewer content={markdownContent} />}
          </div>
        </main>
        <footer className="mt-auto py-4 text-center text-gray-600 text-sm">
          Made with <span className="text-red-500">❤️</span> by MuleSoft Professional Services
        </footer>
      </div>
    </div>
  );
}

export default App;