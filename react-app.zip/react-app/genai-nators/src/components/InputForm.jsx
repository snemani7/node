import React, { useState, useCallback } from 'react';
import { ClipboardIcon } from '@heroicons/react/24/outline';
import { useDropzone } from 'react-dropzone';
import { XMarkIcon, DocumentArrowUpIcon } from '@heroicons/react/24/outline';

const InputForm = ({ onSubmit }) => {
  const [formData, setFormData] = useState({
    repoLink: '',
    platform: '',
    logDump: '',
    documentation: []
  });

  const platforms = [
    { id: 'tibco', name: 'TIBCO' },
    { id: 'sap', name: 'SAP' },
    { id: 'iib', name: 'IIB' }
  ];

  const handleClipboardPaste = async (field) => {
    try {
      const text = await navigator.clipboard.readText();
      setFormData(prev => ({ ...prev, [field]: text }));
    } catch (err) {
      console.error('Failed to read clipboard:', err);
    }
  };

  const [files, setFiles] = useState([]);

  const onDrop = useCallback((acceptedFiles) => {
    setFiles(prev => [...prev, ...acceptedFiles]);
  }, []);

  const removeFile = (fileToRemove) => {
    setFiles(files.filter(file => file !== fileToRemove));
  };

  const { getRootProps, getInputProps, isDragActive } = useDropzone({ 
    onDrop,
    accept: {
      'text/plain': ['.txt'],
      'text/markdown': ['.md'],
      'application/pdf': ['.pdf'],
      'application/msword': ['.doc'],
      'application/vnd.openxmlformats-officedocument.wordprocessingml.document': ['.docx']
    }
  });

  const handleSubmit = (e) => {
    e.preventDefault();
    console.log('Form Data in InputForm:', formData);
    onSubmit(formData);
  };

  return (
        <form onSubmit={handleSubmit} className="mx-auto bg-white p-8 rounded-lg shadow-lg border border-gray-100 space-y-6">
      {/* Repository Link Input */}
      <div className="relative">
        <label className="block text-sm font-medium text-gray-700">
          Code Repository Link <span className="text-red-500">*</span>
        </label>
        <div className="mt-1 flex rounded-md shadow-sm">
          <input
            type="text"
            value={formData.repoLink}
            onChange={(e) => setFormData(prev => ({ ...prev, repoLink: e.target.value }))}
            className="flex-1 rounded-l-md border border-gray-300 px-3 py-2"
            placeholder="Enter repository URL"
            required
          />
          <button
            type="button"
            onClick={() => handleClipboardPaste('repoLink')}
            className="inline-flex items-center rounded-r-md border border-l-0 border-gray-300 px-3 py-2 bg-gray-50 hover:bg-gray-100">
            <ClipboardIcon className="h-5 w-5 text-gray-400" />
          </button>
        </div>
      </div>

      {/* Platform Dropdown */}
      <div>
        <label className="block text-sm font-medium text-gray-700">
          Platform Technology <span className="text-red-500">*</span>
        </label>
        <select
          value={formData.platform}
          onChange={(e) => setFormData(prev => ({ ...prev, platform: e.target.value }))}
          className="mt-1 block w-full rounded-md border border-gray-300 py-2 px-3"
          required
        >
          <option value="">Select technology</option>
          {platforms.map(platform => (
            <option key={platform.id} value={platform.id}>
              {platform.name}
            </option>
          ))}
        </select>
      </div>
      {/* Log Dump Input */}
      <div className="relative">
        <label className="block text-sm font-medium text-gray-700">
          Log Dump <span className="text-gray-400">(Optional)</span>
        </label>
        <div className="mt-1 flex rounded-md shadow-sm">
          <input
            type="text"
            value={formData.logDump}
            onChange={(e) => setFormData(prev => ({ ...prev, logDump: e.target.value }))}
            className="flex-1 rounded-l-md border border-gray-300 px-3 py-2"
            placeholder="Enter log bucket URL"
          />
          <button
            type="button"
            onClick={() => handleClipboardPaste('logDump')}
            className="inline-flex items-center rounded-r-md border border-l-0 border-gray-300 px-3 py-2 bg-gray-50 hover:bg-gray-100"
          >
            <ClipboardIcon className="h-5 w-5 text-gray-400" />
          </button>
        </div>
      </div>

      {/* File Upload Area */}
      <div className="relative">
        <label className="block text-sm font-medium text-gray-700">
          Existing Documentation <span className="text-gray-400">(Optional)</span>
        </label>
        <div 
          {...getRootProps()} 
          className={`mt-1 p-8 border-2 border-dashed rounded-lg cursor-pointer transition-colors
            ${isDragActive ? 'border-[#00A1E0] bg-blue-50' : 'border-gray-300 hover:border-[#00A1E0]'}`}
        >
          <input {...getInputProps()} />
          <div className="flex flex-col items-center justify-center gap-4">
            <DocumentArrowUpIcon 
              className={`h-12 w-12 ${isDragActive ? 'text-[#00A1E0]' : 'text-gray-400'}`}
            />
            <div className="text-center">
              <p className="text-base text-gray-600 font-medium">
                {isDragActive
                  ? "Drop the files here..."
                  : "Drop your files here, or click to browse"}
              </p>
              <p className="text-sm text-gray-500 mt-1">
                Support for .txt, .md, .pdf, .doc, and .docx files
              </p>
            </div>
          </div>
        </div>
      </div>
      {/* File List */}
      {files.length > 0 && (
        <div className="overflow-x-auto">
          <div className="flex space-x-4 p-2">
            {files.map((file, index) => (
              <div 
                key={index}
                className="flex items-center bg-gray-100 rounded-lg p-2 min-w-max group hover:bg-gray-200 transition-colors"
              >
                <DocumentArrowUpIcon className="h-4 w-4 text-gray-500 mr-2" />
                <span className="text-sm text-gray-600 mr-2">{file.name}</span>
                <button
                  type="button"
                  onClick={() => removeFile(file)}
                  className="text-gray-400 hover:text-red-500 transition-colors"
                >
                  <XMarkIcon className="h-4 w-4" />
                </button>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Submit Button */}
      <button
        type="submit"
        className="inline-flex justify-center rounded-md border border-transparent bg-[#00A1E0] px-4 py-2 text-sm font-medium text-white hover:bg-[#0091cc] focus:outline-none focus-visible:ring-2 focus-visible:ring-[#00A1E0] focus-visible:ring-offset-2"
      >
        Migration Magnification
      </button>
    </form>
  );
};

export default InputForm;