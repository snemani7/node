import React from 'react';

const Title = () => {
  const title = "GenAI-nators";
  
  return (
    <div className="py-8">
      <h1 className="text-6xl font-bold text-center bg-gradient-to-r from-blue-600 to-cyan-400 bg-clip-text text-transparent">
        {title}
        <span className="ml-2 inline-block text-blue-800">✨</span>
      </h1>
      {/* <p className="text-center text-gray-600 mt-4 text-xl">
        Transforming Legacy Code into Modern APIs
      </p> */}
    </div>
  );
};

export default Title; 