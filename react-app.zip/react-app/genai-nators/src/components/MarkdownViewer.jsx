import React, { useState, useEffect } from 'react';
import ReactMarkdown from 'react-markdown';
import remarkGfm from 'remark-gfm';
import { Link, Element } from 'react-scroll';
import mermaid from 'mermaid';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faExpand, faCompress, faTimes } from '@fortawesome/free-solid-svg-icons';

mermaid.initialize({
  // Basic configuration
  startOnLoad: true, // Initialize mermaid when page loads
  theme: 'dark', // Use dark theme
  securityLevel: 'loose', // Allow all diagram features
  
  themeVariables: {
    // Primary colors used throughout diagram
    primaryColor: '#ffffff',
    primaryTextColor: '#ffffff', 
    primaryBorderColor: '#ffffff',
    lineColor: '#ffffff',
    secondaryColor: '#ffffff',
    tertiaryColor: '#282c34',
    textColor: '#ffffff',
    
    // Background and border colors
    mainBkg: '#282c34', // Main background color
    nodeBorder: '#ffffff', // Border color for nodes
    clusterBkg: '#282c34', // Background for grouped elements
    
    // Title styling
    titleColor: '#ffffff',
    
    // Edge and connection styling  
    edgeLabelBackground: '#282c34',
    
    // Actor styling (for sequence diagrams)
    actorBorder: '#ffffff',
    actorBkg: '#282c34',
    actorTextColor: '#ffffff',
    actorLineColor: '#ffffff',
    
    // Signal arrow styling
    signalColor: '#ffffff', 
    signalTextColor: '#ffffff',
    
    // Label box styling
    labelBoxBkgColor: '#282c34',
    labelBoxBorderColor: '#ffffff',
    labelTextColor: '#ffffff',
    
    // Loop styling
    loopTextColor: '#ffffff',
    
    // Note styling
    noteBorderColor: '#ffffff',
    noteBkgColor: '#282c34', 
    noteTextColor: '#ffffff',
    
    // Activation/lifeline styling
    activationBorderColor: '#ffffff',
    activationBkgColor: '#3b4048',
    
    // Sequence number styling
    sequenceNumberColor: '#ffffff',
  }
});

const convertToMermaid = (plainText) => {
  if (plainText.includes('participant') && plainText.includes('->')) {
    let mermaidDiagram = 'sequenceDiagram\n';
    const lines = plainText.split('\n');
    lines.forEach(line => {
      line = line.replace(/->/g, '->>')
      if (line.trim()) {
        mermaidDiagram += '    ' + line + '\n';
      }
    });
    return mermaidDiagram;
  }
  return plainText;
};

const MermaidDiagram = ({ content }) => {
  const [svg, setSvg] = useState('');
  const [id] = useState(`mermaid-${Math.random().toString(36).substr(2, 9)}`);
  const [isFullscreen, setIsFullscreen] = useState(false);

  useEffect(() => {
    const renderDiagram = async () => {
      try {
        const { svg } = await mermaid.render(id, content);
        setSvg(svg);
      } catch (error) {
        console.error('Error rendering mermaid diagram:', error);
      }
    };
    renderDiagram();

    // Add escape key listener
    const handleEsc = (event) => {
      if (event.key === 'Escape') {
        setIsFullscreen(false);
      }
    };
    window.addEventListener('keydown', handleEsc);

    return () => {
      window.removeEventListener('keydown', handleEsc);
    };
  }, [content, id]);

  return (
    <div className="relative">
      <button
        onClick={() => setIsFullscreen(!isFullscreen)}
        className="absolute top-2 right-2 bg-gray-700 hover:bg-gray-600 text-white rounded-lg w-8 h-8 flex items-center justify-center text-sm z-10"
      >
        <FontAwesomeIcon icon={isFullscreen ? faCompress : faExpand} />
      </button>
      <div 
        className={`transition-all duration-300 ${
          isFullscreen 
            ? 'fixed inset-0 z-50 bg-gray-900 bg-opacity-90 flex items-center justify-center p-8' 
            : 'relative'
        }`}
      >
        {isFullscreen && (
          <button
            onClick={() => setIsFullscreen(false)}
            className="absolute top-4 right-4 bg-gray-700 hover:bg-gray-600 text-white rounded-lg w-8 h-8 flex items-center justify-center text-sm"
          >
            <FontAwesomeIcon icon={faTimes} />
          </button>
        )}
        <div 
          className={`${isFullscreen ? 'w-full h-full flex items-center justify-center' : ''}`}
          dangerouslySetInnerHTML={{ __html: svg }} 
        />
      </div>
    </div>
  );
};

const MarkdownViewer = ({ content }) => {
  const headers = content
    .split('\n')
    .filter(line => line.startsWith('#'))
    .filter(line => !line.includes('#%RAML'))
    .map(header => ({
      level: header.match(/^#+/)[0].length,
      text: header.replace(/^#+\s/, ''),
      id: header.replace(/^#+\s/, '').toLowerCase().replace(/\s/g, '-')
    }));

  return (
    <div className="grid grid-cols-4 gap-8 p-6 rounded-xl bg-gradient-to-r from-blue-50 to-cyan-50">
      {/* Table of Contents */}
      <div className="col-span-1 bg-white p-6 rounded-lg shadow-lg sticky top-4 h-fit max-h-[calc(100vh-2rem)] overflow-y-auto border border-gray-100">
        <h3 className="text-xl font-bold mb-6 text-gray-800">Table of Contents</h3>
        <nav className="space-y-2">
          {headers.map((header, index) => (
            <Link
              key={index}
              to={header.id}
              spy={true}
              smooth={true}
              duration={500}
              offset={-20}
              activeClass="text-blue-600 font-medium"
              className={`
                block cursor-pointer text-gray-600 hover:text-blue-600 transition-colors
                ${header.level === 1 ? 'font-semibold' : ''}
                ${header.level === 2 ? 'ml-2' : ''}
                ${header.level === 3 ? 'ml-4 text-sm' : ''}
              `}
            >
              {header.text}
            </Link>
          ))}
        </nav>
      </div>

      {/* Markdown Content */}
      <div className="col-span-3 prose prose-slate max-w-none bg-white p-8 rounded-lg shadow-lg">
        <ReactMarkdown 
          remarkPlugins={[remarkGfm]}
          components={{
            h1: ({node, children, ...props}) => (
              <Element name={children[0].toLowerCase().replace(/\s/g, '-')} className="scroll-mt-6">
                <h1 
                  className="text-3xl font-bold mb-6 pb-2 border-b border-gray-200"
                  {...props}
                >
                  {children}
                </h1>
              </Element>
            ),
            h2: ({node, children, ...props}) => (
              <Element name={children[0].toLowerCase().replace(/\s/g, '-')} className="scroll-mt-6">
                <h2 
                  className="text-2xl font-semibold mt-8 mb-4"
                  {...props}
                >
                  {children}
                </h2>
              </Element>
            ),
            h3: ({node, children, ...props}) => (
              <Element name={children[0].toLowerCase().replace(/\s/g, '-')} className="scroll-mt-6">
                <h3 
                  className="text-xl font-medium mt-6 mb-3"
                  {...props}
                >
                  {children}
                </h3>
              </Element>
            ),
            code: ({node, inline, className, children, ...props}) => {
              if (inline) {
                return <code className={className} {...props}>{children}</code>;
              }

              const codeContent = String(children);
              
              // Check if this looks like a sequence diagram
              if (codeContent.includes('participant') && codeContent.includes('->')) {
                const mermaidContent = convertToMermaid(codeContent);
                return <MermaidDiagram content={mermaidContent} />;
              }

              return <code className={className} {...props}>{children}</code>;
            },
            table: ({node, ...props}) => (
              <div className="overflow-x-auto my-6">
                <table className="min-w-full divide-y divide-gray-300" {...props} />
              </div>
            ),
            thead: ({node, ...props}) => (
              <thead className="bg-gray-50" {...props} />
            ),
            th: ({node, ...props}) => (
              <th 
                className="px-6 py-3 text-left text-sm font-semibold text-gray-900"
                {...props} 
              />
            ),
            td: ({node, ...props}) => (
              <td 
                className="px-6 py-4 whitespace-nowrap text-sm text-gray-500"
                {...props} 
              />
            ),
            tr: ({node, ...props}) => (
              <tr 
                className="even:bg-gray-50"
                {...props} 
              />
            ),
            p: ({node, ...props}) => (
              <p className="my-4 text-gray-600 leading-relaxed" {...props} />
            ),
            strong: ({node, ...props}) => (
              <strong className="font-semibold text-gray-900" {...props} />
            ),
            ul: ({node, ...props}) => (
              <ul className="list-disc pl-6 my-4 space-y-2" {...props} />
            ),
            li: ({node, ...props}) => (
              <li className="text-gray-600" {...props} />
            )
         }}
        >
          {content}
        </ReactMarkdown>
      </div>
    </div>
  );
};

export default MarkdownViewer;