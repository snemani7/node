import React from 'react';
import { Link } from 'react-scroll';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faAngleDown } from '@fortawesome/free-solid-svg-icons';

const VideoSection = () => {
  return (
    <div className="h-screen flex flex-col items-center justify-center bg-gradient-to-b from-gray-900 to-gray-800">
      <div className="w-full h-3/4 max-w-6xl px-4">
        <video 
          className="w-full h-full object-cover rounded-lg shadow-2xl"
          controls
        >
          <source src="/poc-story.mp4" type="video/mp4" />
          Your browser does not support the video tag.
        </video>
      </div>
      
      <Link
        to="main-content"
        spy={true}
        smooth={true}
        duration={500}
        className="mt-8 cursor-pointer transform transition-transform hover:translate-y-1"
      >
        <FontAwesomeIcon 
          icon={faAngleDown} 
          className="text-white text-4xl"
        />
      </Link>
    </div>
  );
};

export default VideoSection;